package com.cms.modal;

public class Attachment {

	private String URL;
	private String type;
	private String name;
	private String dlURL;
	private String delURL;
	
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDlURL() {
		return dlURL;
	}
	public void setDlURL(String dlURL) {
		this.dlURL = dlURL;
	}
	public String getDelURL() {
		return delURL;
	}
	public void setDelURL(String delURL) {
		this.delURL = delURL;
	}
	
}
