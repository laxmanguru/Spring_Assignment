package com.cms.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cms.dao.BaseDao;
import com.cms.dao.TagDao;
import com.cms.modal.Tag;

@Service
public class TagService extends BaseService<Tag> {
	
	@Resource
	private TagDao tagDao;
	
	@Override
	public BaseDao<Tag> getDao() {
		// TODO Auto-generated method stub
		return tagDao;
	}
	
	public Tag add(Tag entity) {
		return tagDao.add(entity);
	}

}
