package com.cms.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cms.dao.BaseDao;
import com.cms.dao.CommentDao;
import com.cms.modal.Comment;

@Service
public class CommentService extends BaseService<Comment> {

	@Resource
	private CommentDao commentDao;

	@Override
	public BaseDao<Comment> getDao() {
		return commentDao;
	}

	public Comment add(Comment entity) {
		return commentDao.add(entity);
	}

	@Override
	public void remove(Comment entity) {
		commentDao.remove(entity);
	}
}
