package com.cms.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cms.dao.BaseDao;
import com.cms.dao.PostDao;
import com.cms.modal.Blog;

@Service
public class PostService extends BaseService<Blog> {

	@Resource
	private PostDao postDao;

	@Override
	public BaseDao<Blog> getDao() {
		// TODO Auto-generated method stub
		return postDao;
	}

	public Blog add(Blog entity) {
		return postDao.add(entity);
	}

	public Blog edit(Blog entity) {
		return postDao.edit(entity);
	}

	public void remove(Blog entity) {
		postDao.remove(entity);
	}

}
