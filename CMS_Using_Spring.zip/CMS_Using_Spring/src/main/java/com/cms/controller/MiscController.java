package com.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cms.dao.Page;
import com.cms.modal.Blog;
import com.cms.service.PostService;

@Controller
public class MiscController {
	
	@Resource
	private PostService postService;
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/index")
	public String index(ModelMap modelMap){
		Page page = postService.pagedQuery("from Blog", 1, 10);
		List<Blog> blogs = page.getResult();
		modelMap.addAttribute("blogs",blogs);
		return "index";
	}
	

	public PostService getPostService() {
		return postService;
	}

	public void setPostService(PostService postService) {
		this.postService = postService;
	}
	
	
}
