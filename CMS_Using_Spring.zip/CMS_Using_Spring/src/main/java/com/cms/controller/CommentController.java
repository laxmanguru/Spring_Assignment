package com.cms.controller;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.cms.modal.Comment;
import com.cms.modal.Blog;
import com.cms.service.CommentService;
import com.cms.service.PostService;

@Controller
public class CommentController {
	
	@Resource
	private CommentService commentService;
	@Resource
	private PostService postService;
	
	@RequestMapping(value="article/{post_id}/comment/create",method = RequestMethod.POST)
	public ModelAndView add(Comment comment,@PathVariable("post_id") int post_id,HttpServletRequest request/*,HttpServletResponse response*/){
		comment.setCreated_at(new Date());
		comment = commentService.add(comment);
//		int id = Integer.parseInt(request.getParameter("id"));
		Blog post = postService.get(post_id);
		post.getComments().add(comment);
		post = postService.edit(post);
		return new ModelAndView(new RedirectView(request.getContextPath()+"/article/"+post.getPost_id())); 
	}

	public CommentService getCommentService() {
		return commentService;
	}

	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}

	public PostService getPostService() {
		return postService;
	}

	public void setPostService(PostService postService) {
		this.postService = postService;
	}


	
	
}
